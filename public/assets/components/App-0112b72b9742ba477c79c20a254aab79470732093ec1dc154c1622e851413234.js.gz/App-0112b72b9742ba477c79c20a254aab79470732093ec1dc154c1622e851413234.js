// App.js
import React from 'react';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./Home";
import AboutUs from "./AboutUs";

export default function App() {
  return (

    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home/>}/>
          <Route path="aboutus" element={<AboutUs/>} />
        
      </Routes>
    </BrowserRouter>
  );
}
;
