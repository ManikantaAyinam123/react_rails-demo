// app/javascript/components/AboutUs.js
import React from 'react';

const AboutUs = () => {
  return (
    <div>
      This is about page 
     
    </div>
  );
};

export default AboutUs;
